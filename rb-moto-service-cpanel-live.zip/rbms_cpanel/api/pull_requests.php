<?php
require __DIR__ . '/config.php';
require_key($API_KEY);

$store = read_store($STORE_FILE);
$out = [];
foreach($store as $r){
  if(is_array($r) && ($r['status'] ?? '') === 'new') $out[] = $r;
}
json_response(['ok'=>true,'requests'=>$out]);
