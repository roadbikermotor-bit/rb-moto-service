<?php
// SECURITY:
// - This key is used ONLY for the admin panel (pull + ack).
// - Do NOT share it with customers.
// - Change it after upload.
$API_KEY = 'CHANGE_ME_32CHARS';

// Storage file (JSON)
$STORE_FILE = __DIR__ . '/requests.json';

function json_response($arr, $code=200){
  http_response_code($code);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode($arr, JSON_UNESCAPED_UNICODE);
  exit;
}

function read_store($path){
  if(!file_exists($path)) return [];
  $raw = file_get_contents($path);
  $data = json_decode($raw, true);
  return is_array($data) ? $data : [];
}

function write_store($path, $data){
  $fp = fopen($path, 'c+');
  if(!$fp) return false;
  if(!flock($fp, LOCK_EX)) { fclose($fp); return false; }
  ftruncate($fp, 0);
  rewind($fp);
  fwrite($fp, json_encode($data, JSON_UNESCAPED_UNICODE));
  fflush($fp);
  flock($fp, LOCK_UN);
  fclose($fp);
  return true;
}

function require_key($API_KEY){
  $key = $_GET['key'] ?? '';
  if(!$key || $key !== $API_KEY) json_response(['ok'=>false,'error'=>'Unauthorized'], 401);
}
