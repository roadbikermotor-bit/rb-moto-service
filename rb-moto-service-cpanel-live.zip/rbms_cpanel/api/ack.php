<?php
require __DIR__ . '/config.php';
require_key($API_KEY);

$input = file_get_contents('php://input');
$data = json_decode($input, true);
$ids = $data['ids'] ?? [];
if(!is_array($ids)) $ids = [];
$idsSet = array_fill_keys($ids, true);

$store = read_store($STORE_FILE);
$changed = false;
for($i=0; $i<count($store); $i++){
  $r = $store[$i];
  if(!is_array($r)) continue;
  $id = $r['id'] ?? '';
  if($id && isset($idsSet[$id]) && ($r['status'] ?? '') === 'new'){
    $store[$i]['status'] = 'imported';
    $store[$i]['importedAt'] = gmdate('c');
    $changed = true;
  }
}
if($changed) write_store($STORE_FILE, $store);
json_response(['ok'=>true]);
