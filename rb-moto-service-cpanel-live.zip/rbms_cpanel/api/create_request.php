<?php
require __DIR__ . '/config.php';

$input = file_get_contents('php://input');
$data = json_decode($input, true);
if(!is_array($data)) json_response(['ok'=>false,'error'=>'Invalid JSON'], 400);

// Basic validation
$name = trim($data['name'] ?? '');
$phone = trim($data['phone'] ?? '');
$branch = trim($data['branch'] ?? '');
$problem = trim($data['problem'] ?? '');

if($name === '' || $phone === '' || $branch === '' || $problem === ''){
  json_response(['ok'=>false,'error'=>'Missing required fields'], 422);
}

function uid(){
  return bin2hex(random_bytes(8)) . dechex(time());
}

$req = [
  'id' => uid(),
  'createdAt' => gmdate('c'),
  'status' => 'new',
  'name' => $name,
  'phone' => $phone,
  'branch' => $branch,
  'priority' => trim($data['priority'] ?? 'عادي'),
  'plate' => trim($data['plate'] ?? ''),
  'vin' => trim($data['vin'] ?? ''),
  'serial' => trim($data['serial'] ?? ''),
  'model' => trim($data['model'] ?? ''),
  'year' => trim($data['year'] ?? ''),
  'color' => trim($data['color'] ?? ''),
  'odometer' => trim($data['odometer'] ?? ''),
  'appointmentDate' => trim($data['appointmentDate'] ?? ''),
  'appointmentTime' => trim($data['appointmentTime'] ?? ''),
  'appointmentNotes' => trim($data['appointmentNotes'] ?? ''),
  'problem' => $problem,
  'ua' => substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 200)
];

$store = read_store($STORE_FILE);
$store[] = $req;
if(!write_store($STORE_FILE, $store)){
  json_response(['ok'=>false,'error'=>'Failed to write store'], 500);
}

$ref = strtoupper(substr($req['id'], 0, 8));
json_response(['ok'=>true,'ref'=>$ref]);
